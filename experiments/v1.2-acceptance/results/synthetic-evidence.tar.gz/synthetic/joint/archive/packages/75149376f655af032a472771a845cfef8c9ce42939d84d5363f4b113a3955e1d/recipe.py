import os
import scrapy
from seal.core import SealError
from seal.helpers import attachment_record, diagnostic, html_record, is_attachment_response, json_records, static_resources


class AcceptanceSpider(scrapy.Spider):
    name = "heterogeneous_acceptance"

    def __init__(self, params, context, **kwargs):
        super().__init__(**kwargs)
        self.params, self.context = params, context

    async def start(self):
        for seed in self.context["seeds"]:
            yield scrapy.Request(seed["url"], callback=self.parse,
                                 errback=self.failed, meta={"seal_role":seed["role"]})

    def failed(self, failure):
        yield {"type":"diagnostic", "code":"download_failed"}

    def parse(self, response):
        mode = self.params.get("mode", "api")
        if mode == "api":
            for item in json_records(response):
                if item.get("type") == "record":
                    if self.params.get("projection") == "short" or os.environ.get("SEAL_E2E_RECORD_NONDET"):
                        item["data"].pop("optional")
                        item["locators"].pop("optional")
                    if self.params.get("bad_type"):
                        item["data"]["active"] = int(item["data"]["active"])
                yield item
        elif mode == "assets":
            if response.meta["seal_role"] == "detail":
                if is_attachment_response(response):
                    yield attachment_record(response)
                else:
                    yield html_record(response)
            else:
                yield from static_resources(response, iframe_callback=self.iframe,
                                            attachment_callback=self.attachment,
                                            errback=self.failed)
        elif mode == "parse_failure":
            raise SealError("synthetic_parse_failure")

    def iframe(self, response):
        yield html_record(response)

    def attachment(self, response, parent=None):
        try:
            yield attachment_record(response, parent=parent)
        except SealError as exc:
            yield diagnostic(response, exc.code)
