import scrapy
from seal.helpers import html_record, json_records

class RecheckSpider(scrapy.Spider):
    name = "planned_recheck_acceptance"

    def __init__(self, params, context, **kwargs):
        super().__init__(**kwargs)
        self.context, self.params = context, params

    async def start(self):
        for seed in self.context["seeds"]:
            yield scrapy.Request(seed["url"], callback=self.parse,
                                 meta={"seal_role": seed["role"]})

    def parse(self, response):
        if response.meta["seal_role"] == "api":
            for item in json_records(response, detail_url_field="detail_url"):
                if self.params.get("legacy") and item.get("type") == "record":
                    item["frozen_parent_request"] = None
                yield item
        else:
            yield html_record(response)
